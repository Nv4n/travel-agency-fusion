export const peekLabelStyles =
	"absolute top-0 opacity-0 transition-all group-focus-within:-translate-y-5 group-focus-within:opacity-100";

export const hidePlaceholderStyles =
	"group-focus-within:placeholder:text-transparent";
